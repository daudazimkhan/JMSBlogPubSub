package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Gui extends JFrame
{
	private boolean ready_status;
	private boolean subs_change;
	String pending_subs_tag = new String();
	private ArrayList<String> tags = new ArrayList<>();
	//--------------------------------------------------------
	private JTextArea text_pub = new JTextArea("");
	private JButton btn_add_tag = new JButton("Add Tag");
	private JButton btn_post = new JButton("Post");
	
	public JTextArea text_sub = new JTextArea("");
	private JButton btn_sub_user = new JButton("<html><center>Subscribe<br>User</center></html>");
	private JButton btn_sub_tag = new JButton("<html><center>Subscribe<br>Tag</center></html>");
	//--------------------------------------------------------
	public Gui()
	{
		text_sub.setEnabled(false);
		ready_status = false;
		pending_subs_tag = null;
		//----------------------------------------------------
		text_sub.setBackground(Color.BLACK);
		text_sub.setForeground(Color.GREEN);
		//----------------------------------------------------
		JPanel VPanel = new JPanel();
		VPanel.setLayout(null);
		this.setPreferredSize(new Dimension (800,600));
		this.pack();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//----------------------------------------------------
		// Resize Event
		this.addComponentListener(new ComponentAdapter()
		{
			public void componentResized(ComponentEvent evt)
			{
				resize();
			}
		});
		// Add Tag Button Click Event
		btn_add_tag.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				btnAddTag_Clicked();
			}
		});
		// Post Button Click Event
		btn_post.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				btnPost_Clicked();
			}
		});
		// Add Tag Button Click Event
		btn_sub_user.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				btnSubUser_Clicked();
			}
		});
		// Post Button Click Event
		btn_sub_tag.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				btnSubTag_Clicked();
			}
		});
		//----------------------------------------------------
		VPanel.add(text_pub);
		//VPanel.add(btn_add_tag);
		VPanel.add(btn_post);
		VPanel.add(text_sub);
		VPanel.add(btn_sub_user);
		VPanel.add(btn_sub_tag);
		//----------------------------------------------------
		this.add(VPanel);
	}
	//--------------------------------------------------------
	public void resize()
	{
		//----------------------------------------------------
		int width = this.getContentPane().getWidth();
		int height = this.getContentPane().getHeight();
		//----------------------------------------------------
		text_pub.setBounds(10, 10, width-150, 125);
		btn_add_tag.setBounds(width-130, 10, 120, 50);
		btn_post.setBounds(width-130, 10, 120, 125);
		text_sub.setBounds(10, 145, width-150, height-155);
		btn_sub_user.setBounds(width-130, 145, 120, 100);
		btn_sub_tag.setBounds(width-130, 255, 120, 100);
		//----------------------------------------------------
		this.setPreferredSize(new Dimension((int) this.getSize().getWidth(), (int) this.getSize().getHeight()));
		this.pack();
	}
	public void btnAddTag_Clicked()
	{
		
	}
	public void btnPost_Clicked()
	{
		tags.clear();
		String temp = new String();
		temp = (String) JOptionPane.showInputDialog("Enter Tags seperated by comma:");
		temp = temp.replaceAll(" ", "");
		for(String str : temp.split(","))
		{
			tags.add(str.toString());
		}
		ready_status = true;
	}
	public void btnSubUser_Clicked()
	{
		pending_subs_tag = "_"+(String)JOptionPane.showInputDialog("Enter a Username to subscribe to:")+"_";
		subs_change = true;
	}
	public void btnSubTag_Clicked()
	{
		pending_subs_tag = (String)JOptionPane.showInputDialog("Enter a Tag:");
		subs_change = true;
	}
	//----------------------------------------------------
	public String showLoginBox()
    {
        return (String)JOptionPane.showInputDialog("Enter a Unique Username:");
    }
	public boolean getReadyToPost()
	{
		return ready_status;
	}
	public void setReadyToPost(boolean bln)
	{
		ready_status = bln;
	}
	public void setSubsChange(boolean bln)
	{
		pending_subs_tag = null;
		subs_change = bln;
	}
	public boolean getSubsChange()
	{
		return subs_change;
	}
	public ArrayList<String> getCompose()
	{
		ArrayList<String> str = new ArrayList<>();
		if (text_pub.getText()=="")
			str.add("_EMPTY_");
		else
			str.add(text_pub.getText());
		
		str.addAll(tags);
		
		return str;
	}
	public void clearCompose()
	{
		
	}
	public String getPendingSubsTags()
	{
		return pending_subs_tag;
	}
}
