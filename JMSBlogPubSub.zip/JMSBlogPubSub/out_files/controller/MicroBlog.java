package controller;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;


import model.PubSub;
import view.Gui;

public class MicroBlog
{
	public static void main(String args[]) throws Exception
	{
		final Gui myGUI = new Gui();					// VIew class object <-- myGUI
		final PubSub myPubSub = new PubSub();			// Model class object <-- myPubSub
		myGUI.setVisible(true);
		//-------------------------------------------------
		final String username;
		username = myGUI.showLoginBox();
		//-------------------------------------------------
		class RemindTask extends TimerTask
        {
            @Override
            public void run()
            {
                try
                {
                    if (myGUI.getSubsChange())
                    {
                    	myPubSub.addTags(myGUI.getPendingSubsTags());
                    	
                    	myGUI.setSubsChange(false);
                    }
                    //------------------------------------------------------
                    if (myGUI.getReadyToPost())
                    {
                    	ArrayList<String> temp = new ArrayList<>();
                    	temp = myGUI.getCompose();
                    	temp.add(username);
                    	
                    	myPubSub.publishMyMessage(temp);
                    	
                    	myGUI.setReadyToPost(false);
                    }
                    //------------------------------------------------------
                    myPubSub.getMyMessages();
                    //------------------------------------------------------
                    ArrayList<String> tempArr = new ArrayList<>();
                    tempArr = myPubSub.temp;
                    String strtemp = new String("");
                    for (String str1 : tempArr)
                    {
                    	str1 = str1.replaceFirst("°", ":\n\"");
                    	str1 = str1.replaceFirst("°", "\"\n[");
                    	str1 = str1.concat("]\n-----------------------------------------------------\n");
                    	strtemp = str1+strtemp;
                    }
                    myGUI.text_sub.setText(strtemp);
                }catch (Exception ex) {
                    Logger.getLogger(MicroBlog.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        Timer timer = new Timer();
        timer.schedule(new RemindTask(), 0, 2000);
        //-------------------------------------------------
        
	}
}