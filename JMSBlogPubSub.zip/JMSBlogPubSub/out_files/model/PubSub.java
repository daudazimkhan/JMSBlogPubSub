package model;

import java.util.ArrayList;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ActiveMQTextMessage;

public class PubSub implements MessageListener
{
	public ArrayList<String> temp = new ArrayList<>();
	ActiveMQConnectionFactory factory;
	Connection conn;
	Session session;
	public PubSub() throws JMSException
	{
		factory = new ActiveMQConnectionFactory("tcp://localhost:61616");
	    conn = factory.createConnection();
	    session = conn.createSession(false, Session.AUTO_ACKNOWLEDGE);
	    conn.start(); //Dont know :D
	}
	
	ArrayList<String> subscribed_tags = new ArrayList<>();
	public void addTags(String temp)
	{
		subscribed_tags.add(temp);
	}
	
	public void publishMyMessage(ArrayList<String> temp) throws JMSException
	{
		String msg_text = new String();
		String username = new String();
		
		msg_text = temp.remove(0);
		username = temp.remove(temp.size()-1);
		
		temp.add("_"+username+"_");
		
		try
		{
			for (String str : temp)
	    	{
				Destination destination = session.createTopic(str);
				MessageProducer producer = session.createProducer(destination);
				TextMessage message = new ActiveMQTextMessage();
				message.setText(username+"°"+msg_text+"°"+str);
				conn.start();
				producer.send(message);
	    	}
		    
		}
		catch (JMSException e)
		{
		    // somethings very wrong
		}
		
		
		//pub.closeConnection();
	}
	public void getMyMessages() throws JMSException
	{
		for (String str : subscribed_tags)
    	{
			Destination destination = session.createTopic(str);
			MessageConsumer consumer = session.createConsumer(destination);
			
			consumer.setMessageListener(this);
    	}
	}

	@Override
	public void onMessage(Message arg0) {
		// TODO Auto-generated method stub
		if (!temp.contains(arg0.toString().substring(arg0.toString().indexOf("text = ")+7,arg0.toString().length()-1)))
		{
			//System.out.println(arg0.toString().substring(arg0.toString().indexOf("text = ")+7,arg0.toString().length()-1));
			temp.add(arg0.toString().substring(arg0.toString().indexOf("text = ")+7,arg0.toString().length()-1));
		}
		
	}
}